# MyTrafficWizard

MyTrafficWizard is a web-based application designed to provide users with real-time traffic and weather updates for their planned trips. Users can submit trip details, including departure and destination addresses, and choose their preferred notification channels such as email, SMS, Slack, or Discord. The application then sends timely alerts to users about traffic conditions, estimated travel times, incidents along the route, and weather forecasts.

## Features

- **Trip Alert Requests**: Users can submit trip alert requests by providing departure and destination addresses, plus their contact information.
  
- **Multi-Channel Notifications**: Notifications can be sent through various channels including email, SMS, Slack, and Discord.

- **Real-time Traffic and Weather Updates**: The application fetches real-time traffic data from external traffic APIs and weather data from weather APIs to provide users with accurate updates.

- **Scheduled Alerts**: Users can schedule alerts for future trips, and the system automatically sends notifications at the specified times.

## Architecture Overview

MyTrafficWizard follows an extended MVC design pattern, consisting of the following main subsystems:
- **Models**: Manage data - executes CRUD operations on the database and interfaces with third-party APIs.
  
- **Views**: Interface directly with the user - renders the UI and captures user input through form submissions.
  
- **Controllers**: Serve as the orchestrators of other components - processes user input and coordinates the application's logic.

- **Routes**: Specify the application's accessible endpoints - associates endpoints with controller actions.
  
- **Services**: Offer support to the primary subsystems - includes utilities that enhance the application's functionality.

## Installation

1. Clone the repository: `git clone https://github.com/your-username/my-traffic-wizard.git`
2. Navigate to the project directory: `cd my-traffic-wizard`
3. Install dependencies: `npm install`
4. Set up environment variables such as API keys for TomTom, Gmail, Slack, Discord, etc.
5. Set up a database for the application to use, and retrieve the necessary URL to access it.

## Usage

### Local Development
1. Start the application: `npm start`
2. Access the application via your web browser at `http://localhost:3000`
3. Submit trip details and choose notification preferences.
4. Receive real-time traffic and weather updates for your planned trips.

### Live Website
Visit the live website hosted on [Render](https://mytrafficwizard.onrender.com) to use the application without setting it up locally. Please note, though, that the Render App sleeps after a period of inactivity. If not used recently, it may take a minute or two to load. Please be patient while the Render App wakes up.

### File Names and Descriptions

#### Directory: .github/workflows
Name: externalScheduler.yaml
Description: This GitHub Actions workflow automates HTTP POST requests every 12 minutes, interacting with a scheduling service hosted at mytrafficwizard.onrender.com. It can be triggered automatically or manually via the GitHub UI.

Name: integration_tests.yml
Description: This GitHub Actions workflow, Run_Integration_Tests.yml, is manually triggered via workflow_dispatch to perform integration testing on the latest Ubuntu runner environment. It verifies interactions between integrated modules of the application within a Node.js environment.

Name: unit_tests.yaml
Description: This GitHub Actions workflow, triggered manually via workflow_dispatch, conducts unit testing on the latest Ubuntu runner environment. It checks the codebase's integrity by executing unit tests configured within a Node.js environment.

#### Directory: config
Name: databaseConnection.js
Description: Manages a PostgreSQL connection pool. It automatically closes the pool after a specified period of inactivity to free up resources.

#### Directory: controllers
Name: discordBotController.js
Description: Responsible for controlling messages to Discord. It utilizes the DiscordBotModel class and path module to handle message sending operations.

Name: gmailController.js
Description: Responsible for providing a connection to Gmail for sending email and SMS messages from myTrafficWizard to recipients provided to it. It utilizes the nodemailer package for sending emails.

Name: homeController.js
Description: Responsible for handling requests related to the home/index page. It serves the index.html page, manages static file serving, and handles form submissions. It interacts with the ScheduledTripsModel to submit user-entered trip data to the database.

Name: notificationController.js
Description: Responsible for orchestrating message sending. It instantiates objects of TravelController and WeatherController, as well as a MessageModel object to properly format messages. Additionally, it instantiates objects of GmailController, SlackBotController, and/or DiscordBotController to send alerts.

Name: scheduleController.js
Description: Responsible for controlling the scheduling and processing of trips using a rate-limiting mechanism. It utilizes a trip queue to manage and process trip notifications efficiently.

Name: slackBotController.js
Description: Responsible for controlling messages to Slack.

Name: travelController.js
Description: Orchestrates fetching and presenting travel-related information, including travel times and incidents along a specified route. Utilizes the TravelTimeModel and TravelIncidentModel for fetching data and formats this data as either text or HTML.

Name: weatherController.js
Description: Orchestrates the gathering and presentation of weather data for specific routes. Utilizes services for mapping routes, fetching weather data, and performing reverse geocoding to enhance the data with human-readable addresses. Designed to fetch weather forecasts for waypoints along a defined start and end geographical point and provides the data in both text and HTML formats.

#### Directory: models
Name: addressModel.js
Description: Retrieves a list of near matches to an address entered by a user using the TomTom Search API. Handles everything from exact street addresses to higher-level geographies such as city centers, counties, and states. Encapsulates all interactions with the search API, providing a simple interface for address search.

Name: discordBotModel.js
Description: Processes postMessage requests to Discord. Handles sending messages to Discord users based on input parameters containing user ID and formatted message.

Name: messageModel.js
Description:  Maintains the formatted message output used when sending a scheduled notification to a user. It encapsulates trip data and weather data, providing methods to retrieve text and HTML messages.

Name: scheduledTripsModel.js
Description: Represents the model for scheduled trips, providing functionality to manage trip records in the database. It handles operations such as creating new trips, retrieving trips, updating notification statuses, and deleting trips.

Name: slackBotModel.js
Description: Processes postMessage requests to Slack by sending a POST request to the Slack API. It expects input parameters in a specific format (userID and formattedMessage) and utilizes the Slack API token stored in the environment variables for authorization.

Name: travelIncidentModel.js
Description: Extends BaseFetchRetry to fetch traffic incident data for a specified route. It constructs a request to a traffic API, automatically handling retries for transient errors and rate limits, and parses the response into a structured format. Incidents are sorted by severity with a predefined order, and only the top 10 severe incidents are returned.

Name: travelTimeModel.js
Description: Designed to calculate and provide travel times between two geographical points using the TomTom Routing API. It extends the BaseFetchRetry class to leverage retry capabilities for API requests. This model supports fetching travel times considering various traffic conditions.

Name: weatherModel.js
Description: Manages weather data retrieval and processing for specific geographic points using the Tomorrow.io API. It extends the BaseFetchRetry class to handle API requests with automatic retries on failure.


#### Directory: routes
Name: addressRoutes.js
Description: The route is responsible for calling the AddressModel to retrieve address search data. It accepts address parts from the user interface for searching and returns the results to the user interface.

Name: discordRoutes.js
Description: The routes are used to interact with a Discord bot, allowing users to send messages via a web interface.

Name: homeRoutes.js
Description: Defines routes for the index/home page and static file serving

Name: schedulerRoutes.js
Description: Defines a route for handling POST requests to initiate a scheduling operation with specific concurrency and timing parameters

Name: slackRoutes.js
Description: Defines routes for Slack functions through slackBotController.js. 

#### Directory: services
Name: BaseFetchRetry.js
Description: Executes web API requests with retry logic on transient errors and rate limits. 

Name: reverseGeocode.js
Description:  Extends the BaseFetchRetry class to provide functionality for performing reverse geocoding operations using the TomTom API

Name: routeMappingService.js
Description: Designed to handle the calculation and management of routes between two geographic points. 

#### Directory: static/css
Name: style.css
Description: Provides styling for user interface

#### Directory: static/images
Name: map-placeholder.jpg
Description: Image of map for user interface

Name: wizard.png
Description: Log image for user interface

#### Directory: static/js
Name: discord_bot.js
Description: Used to test the sending of messages via Discord

Name: slack_bot.js
Description: Used to test the sending of messages via Slack

Name: userinterface.js
Description: Provides the user experience

#### Directory: tests/integration
Name: homeControllerscheduledTripsModel.test.js
Description: Integration test

Name: notificationControllertravelController.test.js
Description: Integration test

Name: travelControllertravelIncidentModel.test.js
Description: Integration test

Name: notificationControllerdiscordBotController.test.js  
Description: Integration test

Name: notificationControllerweatherController.test.js   
Description: Integration test

Name: travelControllertravelTimeModel.test.js
Description: Integration test

Name: notificationControllergmailController.test.js
Description: Integration test
                                        
Name: weatherControllerweatherModel.test.js
Description: Integration test

Name: notificationControllermessageModel.test.js 
Description: Integration test
         
Name: scheduleControllernotificationController.test.js
Description: Integration test

Name: notificationControllerslackBotController.test.js
Description: Integration test
    
Name: scheduleControllerscheduledTripsModel.test.js
Description: Integration test

#### Directory: tests/unit/controllers
Name: discordBotController.test.js 
Description: Unit Test

Name: gmailController.test.js 
Description: Unit Test
 
Name: homeController.test.js
Description: Unit Test
  
Name: slackBotController.test.js
Description: Unit Test
  
Name: travelController.test.js
Description: Unit Test
  
Name: weatherController.test.js
Description: Unit Test


#### Directory: tests/unit/models
Name: addressModel.test.js
Description: Unit Test
  
Name: messageModel.test.js
Description: Unit Test
  
Name: scheduledTripsModel.test.js
Description: Unit Test

Name: travelIncidentModel.test.js 
Description: Unit Test

Name: travelTimeModel.test.js 
Description: Unit Test
 
Name: weatherModel.test.js
Description: Unit Test

#### Directory: tests/unit/services
Name: baseFetchRetry.test.js
Description: Unit Test

#### Directory: /tests
Name: send_messages.html
Description: Serves as a test interface for sending messages, particularly for testing the NotificationController class and message processing functionality. It includes a form for entering a trip ID and a button to send messages associated with that trip ID.

Name: slackBotTest.js
Description: Conducts a test of Slack's postMessage functionality. It sends a POST request to the '/slack/postMessage' endpoint with a predefined user ID and formatted message, expecting a response from the server.

Name: testNotificationController.js
Description: Contains tests for the sending of messages using the NotificationController. It allows for manual triggering of the message sending process, which in the final product is managed by the scheduleController.

#### Directory: /views
Name: discord_bot.html
Description: Provides a form for users to input their Discord UserID and a message. Upon submission, it triggers the execution of the Discord bot to process the message.

Name: index.html
Description: This HTML file serves as the user interface for "My Traffic Wizard." It provides a form for users to input trip details, including departure date and time, departure address, destination address, and notification preferences. Users can choose to receive notifications via email, SMS, Discord, or Slack.

Name: slack_bot.html
Description: Provides a form for users to input their Slack UserID and a message. Upon submission, it triggers the execution of the Slack bot to process the message.

#### Directory: /
Name: app.js
Description: Contains the top-level routes and web server functionality for the "My Traffic Wizard" application.

Name: package-lock.json
Description: Manages dependencies in the Node.js project

Name: package.json
Description: Manages dependencies in the Node.js project

## License

All Rights Reserved © Nicole-Rene Newcomb, Tyler Anderson, Philip Baldwin, and Jacob Spalding

## Credits

- This project was developed by Nicole-Rene Newcomb, Tyler Anderson, Philip Baldwin, and Jacob Spalding.
- Special thanks to our Professor, Dr. Mike Mireku Kwakye.


